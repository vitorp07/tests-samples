import xbmc


def main():
	if xbmc.Player().isPlayingVideo():
		base = 'RunScript(script.extendedinfo,info='
		info = xbmc.Player().getVideoInfoTag()
		if xbmc.getCondVisibility('VideoPlayer.Content(movies)'):
			xbmc.executebuiltin('{}extendedinfo,imdb_id={},name={})'.format(base, info.getIMDBNumber(), info.getTitle()))
		elif xbmc.getCondVisibility('VideoPlayer.Content(episodes)'):
			xbmc.executebuiltin('{}extendedtvinfo,name={})'.format(base, info.getTVShowTitle()))


if __name__ == '__main__':
	main()